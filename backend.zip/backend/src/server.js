dotenv.config();

import express from "express";
import dotenv from "dotenv";
import authRoute from "./routes/authRoute.js"
import { connectDB } from "./libs/db.js";
import cookieParser from "cookie-parser";
import cors from "cors";


const app = express();
const PORT = process.env.PORT || 5001;


// middlewares
app.use(express.json());
app.use(cookieParser());
app.use(cors({ origin: process.env.CLIENT_URL, credentials: true }));

// public route
app.use('/api/auth', authRoute);

// private route
app.use(protectedRoute);
app.use("/api/users", userRoute);

connectDB().then(() => {
    app.listen(PORT, () => {
        console.log(`server start on ${PORT}`);
    });
});



//user : kojmko6_db_user
//pass : 9C2XnbBYcvM7zDV5

//pass DB : mongodb+srv://kojmko6_db_user:9C2XnbBYcvM7zDV5@cluster0.mq4yvoy.mongodb.net/?appName=Cluster0