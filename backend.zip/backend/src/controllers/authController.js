import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken';
import crypto from 'crypto';

import User from '../models/User.js';
import Session from '../models/Session.js';

//run commend promt > npm i jsonwebtoken bcrypt cookie-parser

const ACCESS_TOKEN_TTL = '30m'; // normal 15m
const REFRESH_TOKEN_TTL = 14 * 24 * 60 * 60 * 1000; // 14 = day, 24h, 60m, 60s

export const signUp = async(req, res) => {
    try {
        const { username, password, email, firstname, lastname } = req.body;

        if (!username || !password || !email || !firstname || !lastname) {
            return res.status(400).json({
                message: " Please fill all",

            });
        }

        // Check acc user in database
        const duplicate = await User.findOne({ username });

        if (duplicate) {
            return res.status(409).json({
                message: "Username already have in System"
            });
        }

        // bcrypt pass == encrypt
        const hashedPassword = await bcrypt.hash(password, 10); // salt = 10 example = {Mypassword} => {My%#131e3P12egw}


        // create new user
        await User.create({
            username,
            hashedPassword,
            email,
            displayName: `${firstname} ${lastname}`
        });


        // return
        return res.sendStatus(204); //204 = request success


    } catch (error) {
        console.error("Error call signup?", error);
        return res.status(500).json({
            message: "Error System"
        });
    }


};

export const signIn = async(req, res) => {

    try {

        // get input
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({ message: "Empty username or password." });
        }

        // get hashedpassword in database to compare password input
        const user = await User.findOne({ username });

        if (!user) {
            return res.status(400).json({ message: 'username or password incorrect!' });
        }

        // check password
        const passwordCorrect = await bcrypt.compare(password, user.hashedPassword);

        if (!passwordCorrect) {
            return res.status(401).json({ message: "username or password incorrect!" });
        }

        // after check create token with JWT   // before write this line run prompt > require('crypto').randomBytes(64).toString('hex')
        const accessToken = jwt.sign({ userId: user._id },

            process.env.ACCESS_TOKEN_SECRET, { expiresIn: ACCESS_TOKEN_TTL }
        );


        // create refresh token
        const refreshToken = crypto.randomBytes(64).toString('hex');


        // create session new to save refresh token
        await Session.create({
            userId: user._id,
            refreshToken,
            expiresAt: new Date(Date.now() + REFRESH_TOKEN_TTL),

        });


        // send refresh token to cookie
        res.cookie('refreshToken', refreshToken, {
            httpOnly: true,
            secure: true,
            sameSite: 'none', // Backend, Frontend deploy not same
            maxAge: REFRESH_TOKEN_TTL,
        })

        // send back access token inside respon
        return res.status(200).json({ message: `User ${user.displayName} was logged in.`, accessToken });


    } catch (error) {
        console.error("Error SignIn!", error);
        return res.status(500).json({ message: "Error System." });
    }


};
export const signOut = async(req, res) => {
    try {
        // get refresh token from cookie
        const token = req.cookies.refreshToken;

        if (token) {
            // Delete refresh token trong Session
            await Session.deleteOne({ refreshToken: token });

            // Delete cookie
            res.clearCookie("refreshToken");
        }

        return res.sendStatus(204);
    } catch (error) {
        console.error("Error when call signOut", error);
        return res.status(500).json({ message: "Error System" });
    }
};

// create access token new from refresh token
export const refreshToken = async(req, res) => {
    try {
        // get refresh token from cookie
        const token = req.cookies.refreshToken;
        if (!token) {
            return res.status(401).json({ message: "Token not have in system." });
        }

        // compare  refresh token in db
        const session = await Session.findOne({ refreshToken: token });

        if (!session) {
            return res.status(403).json({ message: "Token incorrect." });
        }

        // check token expire date
        if (session.expiresAt < new Date()) {
            return res.status(403).json({ message: "Token was expired." });
        }

        // create access token new
        const accessToken = jwt.sign({
                userId: session.userId,
            },
            process.env.ACCESS_TOKEN_SECRET, { expiresIn: ACCESS_TOKEN_TTL }
        );

        // return
        return res.status(200).json({ accessToken });
    } catch (error) {
        console.error("Error when call refreshToken", error);
        return res.status(500).json({ message: "Error System" });
    }
};